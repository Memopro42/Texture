#version 150

#moj_import <fog.glsl>
#moj_import <matrix.glsl>
#moj_import <frag_utils.glsl>
#moj_import <config.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform vec4 FogColor;
uniform float FogStart;
uniform float GameTime;
uniform float FogEnd;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
in vec4 texProj0;
in vec3 screenLocation;

out vec4 fragColor;

void main() {	
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) discard; 	
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
	
	ivec4 ctrlF = ivec4(color * 255.0 + 0.5);
    
	switch (ctrlF.a) {
	case 251: if (Ender_Chest) {
			vec2 screenSize = gl_FragCoord.xy / (screenLocation.xy / screenLocation.z * 0.5 + 0.5);
			color.rgb = Endportal_Colors[0] * vec3(0.463, 0.337, 0.647);
			for (int i = 0; i < Portal_Layers; i++) {
				vec4 proj = vec4(gl_FragCoord.xy / screenSize, 0, 1) * end_portal_layer(i + 1.0, GameTime);
				float pixel = hash12(floor(fract(proj.xy / proj.w) * 256.0));
				color.rgb += (step(0.95, pixel) * 0.2 + step(0.99, pixel) * 0.8) * Endportal_Colors[i];
			}
		} break;
	case 250: if (Emissives) break;
	case 2: discard; break;
	default: color *= vertexColor * lightMapColor; break;
	}
	
	fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
	fragColor.rgb = cone_filter(Colorblindness, fragColor.rgb);
}