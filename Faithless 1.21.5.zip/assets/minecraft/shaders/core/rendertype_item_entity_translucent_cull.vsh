#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>
#moj_import <config.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform float GameTime;
uniform int FogShape;
uniform mat3 IViewRotMat;
uniform float FogStart;
uniform float FogEnd;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

vec3 liquid_render(float value) {
    float waveOffset = (Position.x + Position.y + Position.z + GameTime * 4000.0) * 0.333;
    float base = sin(waveOffset) + sin(waveOffset * 2.1) + sin(waveOffset * 5.15);
    vec3 wave = sin((waveOffset + vec3(1.0, -1.0, 1.0) * Position) * 0.368) * value * vec3(0.02, 0.01, 0.02);
    return base * wave + vec3(0.0, -value * 0.02, 0.0);
}

void main() {
    texCoord0 = UV0, texCoord1 = UV1, texCoord2 = UV2;
	vec4 tint = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    vec3 pos = Position;
	
	ivec4 ctrlV = ivec4(textureLod(Sampler0, UV0, 0) * 255.0 + 0.5);
		
	switch (ctrlV.a) {
	case 255: case 0: break;
	case 250: if (Emissives) tint = vec4(1.0); break;
	case 239: pos += liquid_render(0.3); break;		//Bucket Liquid & Soups
	case 1: pos += liquid_render(0.3); break;		//Bucket Liquid & Soups
	default: break;
	}
	
	vertexColor = tint;
    vertexDistance = fog_distance(pos, FogShape);
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
