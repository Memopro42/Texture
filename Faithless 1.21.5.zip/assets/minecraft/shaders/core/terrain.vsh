#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>
#moj_import <vertex_utils.glsl>
#moj_import <config.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;
uniform sampler2D Sampler0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ModelOffset;
uniform float GameTime;
uniform int FogShape;
uniform float FogEnd;

out float vertexDistance;
out float vertexHeight;
out vec4 vertexLight;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 rendWave(vec3 chunkPos, float value) {
	float seed = (chunkPos.x * 256 + chunkPos.y * 16 + chunkPos.z) / (17 - chunkPos.z) * 5;
    float wave = (seed * 0.1 + GameTime * 4000.0) * 0.333;
    float offset = sin(wave) + sin(wave * 2.1) + sin(wave * 5.15);
    return offset * vec3(0.01, 0.008, 0.01) * value;
}

vec3 rendWind(vec3 chunkPos, float value) {
    float seed = chunkPos.x + chunkPos.z;
    vec2 wind = sin(vec2(0.05, 0.30) * seed + GameTime * vec2(1234.0, 3210.0));
    return vec3(wind.x * 0.2, 0, wind.y * 0.05) * value;
}

vec3 rendLiquid(vec3 chunkPos, float yPos, float value, inout vec4 tint) {
	float seed = (chunkPos.x * 256 + chunkPos.y * 16 + chunkPos.z) / (17 - chunkPos.z) * 5;
	float wave = 0.0;
	for (int i = 1; i <= 5; i++) {
		wave += sin(seed * i + GameTime * (6000.0 / i));
	}
	vec3 offset = wave * vec3(0.04, 0.06, 0.04) * fract(yPos);
	tint += offset.y * vec4(-0.7, 1.0, -0.4, 1.0);
    return offset * value;
}

vec3 rendSwing(vec3 blockPos, float value) {
	vec3 rand = floor(Position);
    float theta = GameTime * 1600.0 + dot(rand, vec3(1.0));
    float sinX = sin(theta) * 0.1, sinZ = sin(theta * 1.618) * 0.1;
    float cosX = 1.0 - 0.5 * sinX * sinX, cosZ = 1.0 - 0.5 * sinZ * sinZ;
    blockPos.yz = vec2(cosX * blockPos.y - sinX * blockPos.z, sinX * blockPos.y + cosX * blockPos.z);
    blockPos.xy = vec2(cosZ * blockPos.x - sinZ * blockPos.y, sinZ * blockPos.x + cosZ * blockPos.y);
    return (-Position + blockPos + rand + 0.5) * value;
}

float rendBounce() {
    float t = fract(GameTime * 6000.0) * 2.0 - 1.0;
    return (t * t) * -0.008;
}

vec3 rendPulse(vec3 blockPos) {
    float t = fract(GameTime * 3000.0) * 2.0 - 1.0; 
    return blockPos * max(0.0, 1.0 - t * t) * 0.1;
}

vec3 rendOrbital(vec3 pos, vec3 blockPos) {
	pos -= blockPos;
	float theta = GameTime * 2500.0;
	float sinTheta = sin(theta), cosTheta = cos(theta);
	
	mat3 rot = mat3(
		vec3(1.0, 0.0, 0.0), 
		vec3(0.0, cosTheta, -sinTheta), 
		vec3(0.0, sinTheta, cosTheta)) *
		mat3(vec3(cosTheta, 0.0, sinTheta), vec3(0.0, 1.0, 0.0), vec3(-sinTheta, 0.0, cosTheta)) *
		mat3(vec3(cosTheta, -sinTheta, 0.0), vec3(sinTheta, cosTheta, 0.0), vec3(0.0, 0.0, 1.0));
	
	blockPos *= 1.0 + max(0.0, sin(GameTime * 20000.0) - 0.8) * 0.25;
	return pos + vec3(0.0, 0.07, 0.0) + blockPos * rot;
}

vec3 rendRotation(vec3 pos, vec3 blockPos) {
    pos -= blockPos;
    float theta = GameTime * 4000.0;
    float cosTheta = cos(theta), sinTheta = sin(theta);
    blockPos.xz = mat2(cosTheta, -sinTheta, sinTheta, cosTheta) * blockPos.xz;
    return pos + blockPos;
}

vec3 rendHeartbeat(vec3 blockPos) {
    vec3 t = fract(GameTime * vec3(200.0, 500.0, 1000.0)) * 1.0 - 0.5;
    vec3 pulse_vals = max(vec3(0.0), 0.5 - t * t);
    return blockPos * (pulse_vals.x + max(0.0, pulse_vals.y + pulse_vals.z - 0.8)) * 0.5;
}

vec3 slopes(vec3 pos, vec3 blockPos, int ctrl) {
	if (ctrl == 240 || ctrl == 239) {
		float slope_offset = clamp((1.0 - Color.r), 0.0, -blockPos.y + 0.5);
		pos.y += slope_offset;
		if (Normal.y > 0.0 && ctrl == 240) {
			float elevation = 0.5 - slope_offset - blockPos.y;
			texCoord0.y -= elevation * 16.0 / textureSize(Sampler0, 0).y;
		}
	} else { pos.y -= blockPos.y + 0.5; }
    return pos;
}

vec3 grass_physics(vec3 pos, mat4 ModelViewMat) {
    if (pos.y < ModelViewMat[3].y + 0.8) {
        vec2 dist = vec2(length(pos.xz - ModelViewMat[3].xz), abs(pos.y - ModelViewMat[3].y));		
        float smoothFactor = max(0.0, 1.0 - (dist.x - 0.3) * 1.444) * max(0.0, 1.0 - (dist.y - 0.5) * 0.666);		
        pos.y = mix(pos.y, -1.5, smoothFactor);
        pos += normalize(vec3(ModelViewMat[2].x, 0.0, -ModelViewMat[2].z)) * smoothFactor;
    }
    return pos;
}

void main() {
    texCoord0 = UV0;
	vec4 tint = Color;
	vec4 shade = minecraft_sample_lightmap(Sampler2, UV2);
	
	mat4 ViewMat = Orthographic ? getOrthoMat(ProjMat, 0.007) : ProjMat;
	mat4 Camera = Orthographic ? getIsometricViewMat(ModelViewMat) : ModelViewMat;
	
    vec3 pos = Position + ModelOffset;
	vec3 blockPos = fract(Position) - 0.5;
	vec3 chunkPos = mod(round(Position), 16) + 1;
    int vertID = gl_VertexID % 4;

    switch (Chunk_Loading) {
    case 1: pos.y += chunk_translate(ModelOffset, FogEnd); break;
    case 2: pos += chunk_quad_fade(ModelOffset, Normal, Position, FogEnd, vertID); break;
    }
    	
	ivec4 ctrlV = ivec4(textureLod(Sampler0, UV0, 0) * 255.0 + 0.5);
	
	switch (ctrlV.a) { //X - can potentially be combined
	case 255: case 0: break;
	case 254: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Foliage); break;		// Leaves & Vines
	case 252: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Foliage * 0.25); break;// Bamboo & Dripleaf
	case 251: if (Waving_Features) 	pos += rendWind(chunkPos, Waving_Grass); break;			// Grass, Crops & Flowers
	case 250: if (Emissives) 		tint = vec4(1.0); break;								// Emissives
	case 249: if (Waving_Features) 	pos += rendSwing(blockPos, Waving_Objects); break;		// Hanging Lanterns
	case 248: if (Emissives) 		tint = vec4(1.0);										// Spinning Beacon
			  if (Block_Animations) pos = rendOrbital(pos, blockPos); break;
	case 247: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Objects); break;		// Chains & Webs 
	case 246: if (Fencelogging) 	pos.y += 0.5; break;									// Fencelogging 
	case 245: if (Block_Animations) pos = rendRotation(pos, blockPos); break;				// X Jukebox Disc
	case 244: if (Block_Animations) pos += rendPulse(blockPos); break;						// X
	case 243: if (Block_Animations) pos.y += rendBounce(); break;							// X
	case 242: if (Windowlogging) 	pos.y += 0.5; break; 									// Windowlogging Top/Bottom 
	case 241: if (Windowlogging) 	pos.y += 1.0; break; 									// Windowlogging Sides
	case 240: 																				// X Snow & Moss Layers
	case 239:																				// X
	case 238: if (Dynamic_Slopes) 	pos = slopes(pos, blockPos, ctrlV.a); break;			// X
	case 237: if (Emissives) 		tint = vec4(1.0);										// Lava & Cauldron
			  if (Waving_Features) 	pos += rendLiquid(chunkPos, blockPos.y, Waving_Lava * 0.5, tint); break;
	case 235: if (Big_Trees) 		pos.y += 3.0; break;									// X 2x2 Log Bark
	case 234: if (Block_Animations) pos += rendHeartbeat(blockPos); break;					// Creaking heartbeat
	case 200: if (Waving_Features) 	pos += rendLiquid(chunkPos, blockPos.y, Waving_Water, tint); break;	// (TRANSLUCENT) Water & Cauldron 
	case 191: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Objects); break;		// (TRANSLUCENT) Nether Portal
	case 181: if (Block_Animations) pos += rendSwing(blockPos, Waving_Objects); break;		// (TRANSLUCENT) Slime and Honey
	case 145: if (Windowlogging) 	pos.y += 0.5; break;									// X (TRANSLUCENT) Windowlogging Stained Glass Top
	case 143: if (Windowlogging) 	pos.y += 1.0; break;									// X (TRANSLUCENT) Windowlogging Stained Glass Sides
	case 25: // -=- (CUTOUT) -=-
		switch (ctrlV.r) {
		case 2: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Foliage * 0.5); break;	// Bushes, Vines, & Chorus trees
		case 3: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Foliage * 0.25); break;// Bamboo & Dripleaf
		case 4: if (Waving_Features) 	pos += rendWind(chunkPos, Waving_Grass);				// Grass, Crops & Flowers
				if (Displacement) 		pos = grass_physics(pos, ModelViewMat); break; 						
		case 5: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Fire); break; 			// Fire & Campfire
		case 6: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Water * 1.5); 			// Seagrass
				if (Displacement) 		pos = grass_physics(pos, ModelViewMat); break; 						
		case 7: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Water * 1.5); break; 	// Lily Pad & Kelp
		case 8: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Objects); break;		// Tripwire Hook
		case 9: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Grass); break; 		// Flowerbeds and Clovers
		case 10: if (Windowlogging) 	pos.y += 0.5; break; 									// X Windowlogging Top/Bottom
		case 11: if (Windowlogging) 	pos.y += 1.0; break; 									// X Windowlogging Sides
		case 12: if (Big_Trees) 		pos.y += 3.0; break; 									// X 2x2 Log Side
		case 13: if (Big_Trees) 		pos.z -= 3.0; break; 									// X 2x2 Log Core
		} break;
	case 2: if (Waving_Features) 	pos += rendWave(chunkPos, Waving_Foliage); break; 		// Leaves Cutout
	case 1: // -=- (TRANSLUCENT) -=-
		switch (ctrlV.r) {
		case 1: if (Portal_Fog) pos.x += (fract(Position.x) == 0.5) ? -1.5 : 1.5; break;		// X Portal Fog [North/South]
		case 2: if (Portal_Fog) pos.z += (fract(Position.z) == 0.5) ? -1.5 : 1.5; break;		// X Portal Fog [East/West]
		case 3: if (Waving_Features) pos += rendWave(chunkPos, Waving_Objects); break; 			// Tripwire
		} break;
	}
	
	vertexLight = shade;
	vertexColor = tint;
	vertexHeight = pos.y;
	vertexDistance = fog_distance(pos, FogShape);
	gl_Position = ViewMat * Camera * vec4(pos, 1.0);
}

// SOLID SHADERS
//
//	switch (alpha) {
//	case 25:
//		switch (red) {
//		case 1: if (Dimensional_Foliage) { 
//					if (Position.z > floor(Position.z)) { position.z -= 3; }// Nether Algae
//					position.y += 9.0; 
//					if (Waving_Features && Waving_Lava > 0) position = liquid_render(position, Position, GameTime * 0.5); 
//				} break;
//		case 2: if (Dimensional_Foliage) position.z += 2.0; break;// End Shrooms
//		case 6: if (Dimensional_Foliage) { position.y += 1.0;// End Grass
//				 if (Waving_Features && Waving_Grass > 0) position = wave_render(position, Waving_Grass, GameTime);
//				 if (Grass_Displacement) position = grass_displacement(position, ModelViewMat); } break;
//		case 7: if (Dimensional_Foliage) { position.y += 2.0;// End Tallgrass
//				 if (Waving_Features && Waving_Grass > 0) position = wave_render(position, Waving_Grass, GameTime);
//				 if (Grass_Displacement) position = grass_displacement(position, ModelViewMat); } break;
//		} break;
//	}