#version 150

#moj_import <frag_utils.glsl>
#moj_import <config.glsl>
#moj_import <fog.glsl>

uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in vec2 texCoord0;
in float vertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    fragColor = linear_fog(vertexColor, vertexDistance, FogStart + 128, FogEnd + 64, FogColor);;
	fragColor.rgb = cone_filter(Colorblindness, fragColor.rgb);
}