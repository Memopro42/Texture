#version 150

#moj_import <projection.glsl>

in vec3 Position;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ModelOffset;

out vec4 texProj0;

void main() {
    vec3 pos = Position + ModelOffset;	
	if (PORTAL_LAYERS == 15) pos.y -= 0.746;	
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    texProj0 = projection_from_position(gl_Position);
}
