#version 150

#moj_import <fog.glsl>
#moj_import <frag_utils.glsl>
#moj_import <config.glsl>

uniform sampler2D Sampler0;

uniform vec4 FogColor;
uniform float FogStart;
uniform float FogEnd;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0) discard; 
	
	vec4 tint = vertexColor;
	ivec4 ctrl = ivec4(color * 255.0 + 0.5);	
    
	switch (ctrl.a) {
	case 255: break;
	case 250: color.a = 1.0; if (Emissives) tint = vec4(1.0); break;
	case 239: color.a = 1.0; break;
	}
	
	color *= tint;
	fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
	fragColor.rgb = cone_filter(Colorblindness, fragColor.rgb);
}
