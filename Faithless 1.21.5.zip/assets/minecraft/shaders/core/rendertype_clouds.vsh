#version 150

#moj_import <fog.glsl>
#moj_import <config.glsl>

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ModelOffset;
uniform int FogShape;
uniform vec4 ColorModulator;

out float vertexDistance;
out vec4 vertexColor;

void main() {
    vec3 pos = Position + ModelOffset;
	vec4 tint = Color;
	ivec4 CtrlV = ivec4(Color * 255 + 0.5);
	
	if (!Layered_Clouds) { CtrlV.a = 255; tint.a = 0.5; }
    if (Sunken_Clouds) pos.y += CtrlV.a * ColorModulator.r - 130;

	if (Puffy_Clouds) {
		tint = vec4(vec3(1.0), Color.r);
		int vertID = gl_VertexID % 4;	
		if (CtrlV.r == 255 || (CtrlV.r == 204 || CtrlV.r == 229) && (vertID == 1 || vertID == 2)) { 
			pos.y += 8; 
			tint.a = 0.0;
		}	
	}

    vertexColor = tint * ColorModulator;
    vertexDistance = fog_distance(pos, 1);
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
