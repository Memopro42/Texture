#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>
#moj_import <config.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform float GameTime;
uniform int FogShape;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

out float vertexDistance;
out vec4 vertexColor;
out vec4 lightColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
out vec3 screenLocation;

#define ENTITY_COUNT 7
vec4[ENTITY_COUNT] entity = vec4[ENTITY_COUNT] (
    vec4(0, 0, 1, 128) * 0.00392,	//Pig 
    vec4(0, 0, 2, 128) * 0.00392,	//Cow 
    vec4(0, 0, 3, 128) * 0.00392,	//Enderman 
    vec4(0, 0, 4, 128) * 0.00392,	//Blaze 
    vec4(0, 0, 5, 128) * 0.00392,	// 
    vec4(0, 0, 6, 128) * 0.00392,	//MagmaCube 
    vec4(0, 0, 7, 128) * 0.00392	//WitherSkeleton 
);

void main() {
	vec3 pos = Position;
	
	vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
	
	lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
	overlayColor = texelFetch(Sampler1, UV1, 0);
    texCoord0 = UV0;
	
    if (Fresh_Animations) {
        float alpha = texelFetch(Sampler0, ivec2(0, 0), 0).a;

        if (abs(alpha - 128.0/255.0) < 0.001) {
            float blue = texelFetch(Sampler0, ivec2(0, 0), 0).b;
            int entityId = int(blue * 255.0);

            switch (entityId) {
                case 1: //Pig
                    break;
                case 2: //Cow
                    break;
                case 3: //Enderman
                    vertexColor = Color;
                    break;
                case 4: //Blaze
                    vertexColor = Color;
                    break;
                case 5: //UNUSED
                    break;
                case 6: //MagmaCube
                    vertexColor = Color;
                    break;
                case 7: //WitherSkeleton
                    vertexColor = Color;
                    break;
                default:
                    break;
            }
        }
    }
	
    vertexDistance = fog_distance(pos, FogShape);	
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    if (Ender_Chest) screenLocation = gl_Position.xyw;
}
